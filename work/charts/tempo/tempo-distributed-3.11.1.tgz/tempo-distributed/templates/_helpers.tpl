{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "tempo.name" -}}
{{- default "tempo" .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Safely convert a value to int with fallback.

Accepts int, float64 (e.g. 15.0), or numeric strings (e.g. "15").
Falls back to default for invalid values (e.g. "abc", nil).

Usage:
  {{ include "tempo.safeInt" (dict "value" $v "default" 30) }}

Args:
  value: input value to convert
  default: fallback integer if value is invalid
*/}}
{{- define "tempo.safeInt" -}}
{{- $v := index . "value" -}}
{{- $default := index . "default" -}}

{{- if or
  (kindIs "int" $v)
  (kindIs "float64" $v)
  (and (kindIs "string" $v) (eq (toString (toString $v | int)) $v))
}}
  {{- toString $v | int -}}
{{- else -}}
  {{- $default -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "tempo.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default "tempo" .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Docker image selector for Tempo. Hierarchy based on global, component, and tempo values.
*/}}
{{- define "tempo.tempoImage" -}}
{{- $registry := coalesce .component.registry .tempo.registry .global.registry -}}
{{- $repository := coalesce .component.repository .tempo.repository -}}
{{- $tag := coalesce .component.tag .tempo.tag .defaultVersion | toString -}}
{{- printf "%s/%s:%s" $registry $repository $tag -}}
{{- end -}}

{{/*
Optional list of imagePullSecrets for Tempo docker images
*/}}
{{- define "tempo.imagePullSecrets" -}}
{{- $imagePullSecrets := coalesce .component.pullSecrets .tempo.pullSecrets .global.pullSecrets -}}
{{- if $imagePullSecrets  -}}
imagePullSecrets:
{{- range $imagePullSecrets }}
  - name: {{ . }}
{{ end }}
{{- end }}
{{- end -}}

{{/*
Generic component imagePullSecrets. Resolves the component's values section
dynamically, following the same pattern as tempo.imageReference.
Params:
  ctx = root context (.)
  component = component name (e.g., "distributor", "query-frontend")
  noTempoFallback = optional, when true the tempo image is not used as fallback (for non-tempo images like gateway)
*/}}
{{- define "tempo.componentImagePullSecrets" -}}
{{- $componentSection := include "tempo.componentSectionFromName" . -}}
{{- if not (hasKey .ctx.Values $componentSection) -}}
{{- print "Component section " $componentSection " does not exist" | fail -}}
{{- end -}}
{{- $component := (index .ctx.Values $componentSection).image | default dict -}}
{{- $tempo := .ctx.Values.tempo.image -}}
{{- if .noTempoFallback -}}
{{- $tempo = dict -}}
{{- end -}}
{{- $dict := dict "tempo" $tempo "component" $component "global" .ctx.Values.global.image -}}
{{- include "tempo.imagePullSecrets" $dict -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "tempo.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Calculate image name based on whether enterprise features are requested.  Fallback to hierarchy handling in `tempo.tempoImage`.
*/}}
{{- define "tempo.imageReference" -}}
{{ $tempo := "" }}
{{- if .ctx.Values.enterprise.enabled -}}
{{ $tempo = merge .ctx.Values.enterprise.image .ctx.Values.tempo.image }}
{{- else -}}
{{ $tempo = .ctx.Values.tempo.image }}
{{- end -}}
{{- $componentSection := include "tempo.componentSectionFromName" . }}
{{- if not (hasKey .ctx.Values $componentSection) }}
{{- print "Component section " $componentSection " does not exist" | fail }}
{{- end }}
{{- $component := (index .ctx.Values $componentSection).image | default dict }}
{{- $dict := dict "tempo" $tempo "component" $component "global" .ctx.Values.global.image "defaultVersion" .ctx.Chart.AppVersion -}}
{{- include "tempo.tempoImage" $dict -}}
{{- end -}}

{{/*
Simple resource labels
*/}}
{{- define "tempo.labels" -}}
helm.sh/chart: {{ include "tempo.chart" .ctx }}
app.kubernetes.io/name: {{ include "tempo.name" .ctx }}
app.kubernetes.io/instance: {{ .ctx.Release.Name }}
{{- if .component }}
app.kubernetes.io/component: {{ .component }}
{{- end }}
{{- if .memberlist }}
app.kubernetes.io/part-of: memberlist
{{- end }}
{{- if .ctx.Chart.AppVersion }}
app.kubernetes.io/version: {{ .ctx.Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .ctx.Release.Service }}
{{- if .rolloutZoneName }}
rollout-group: {{ .component }}
zone: {{ .rolloutZoneName }}
{{- end }}
{{- if .ctx.Values.global.commonLabels }}
{{ toYaml .ctx.Values.global.commonLabels | indent 0 }}
{{- end }}
{{- if .ctx.Values.global.labels }}
{{ toYaml .ctx.Values.global.labels | indent 0 }}
{{- end }}
{{- end -}}

{{/*
Simple service selector labels
Params:
  ctx = . context
  component = name of the component (optional)
  rolloutZoneName = rollout zone name (optional); makes the selector match one zone only
*/}}
{{- define "tempo.selectorLabels" -}}
app.kubernetes.io/name: {{ include "tempo.name" .ctx }}
app.kubernetes.io/instance: {{ .ctx.Release.Name }}
{{- if .component }}
app.kubernetes.io/component: {{ .component }}
{{- end }}
{{- if .rolloutZoneName }}
{{- if not .component }}
{{- printf "Component name cannot be empty if rolloutZoneName (%s) is set" .rolloutZoneName | fail }}
{{- end }}
rollout-group: {{ .component }}
zone: {{ .rolloutZoneName }}
{{- end -}}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "tempo.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "tempo.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Resource name template
Params:
  ctx = . context
  component = name of the component (optional)
  rolloutZoneName = rollout zone name (optional); appended as a suffix
*/}}
{{- define "tempo.resourceName" -}}
{{ include "tempo.fullname" .ctx }}{{- if .component -}}-{{ .component }}{{- end -}}{{- if .rolloutZoneName -}}-{{ .rolloutZoneName }}{{- end -}}
{{- end -}}

{{/*
Governing service of a StatefulSet.
Params:
  ctx       = root context
  component = component name string (e.g. "live-store")
*/}}
{{- define "tempo.governingServiceName" -}}
{{- if .ctx.Values.tempo.useHeadlessGoverningService -}}
{{ include "tempo.resourceName" . }}{{ if eq .component "metrics-generator" }}-discovery{{ end }}
{{- else -}}
{{ .component }}
{{- end -}}
{{- end -}}

{{/*
Calculate the config from structured and unstructured text input
*/}}
{{- define "tempo.calculatedConfig" -}}
{{ tpl (mergeOverwrite (tpl .Values.config . | fromYaml) .Values.tempo.structuredConfig | toYaml) . }}
{{- end -}}

{{/*
Build the cache section for tempo.yaml.
When the shared memcached cluster or any per-role memcached section is enabled,
auto-generates cache.caches. Each enabled per-role section gets its own entry;
roles without a dedicated instance fall back to the shared cluster. When the
shared cluster is disabled, they fall back to the entries in .Values.cache
instead, skipping any entry that points at the undeployed shared host.
When nothing is enabled, outputs the user-defined cache block from values.yaml
verbatim, which is how an externally managed cache is configured.
*/}}
{{- define "tempo.cacheConfig" -}}
{{- $fullname := include "tempo.fullname" . -}}
{{- $roles := list "parquet-footer" "bloom" "frontend-search" -}}
{{- $perRoleMap := dict
    "parquet-footer"  (dict "section" "memcachedParquetFooter"  "component" "memcached-parquet-footer")
    "bloom"           (dict "section" "memcachedBloom"          "component" "memcached-bloom")
    "frontend-search" (dict "section" "memcachedFrontendSearch" "component" "memcached-frontend-search") -}}
{{- $sharedRoles := list -}}
{{- $anyPerRole := false -}}
{{- range $role := $roles -}}
  {{- $mapping := get $perRoleMap $role -}}
  {{- $vals := index $.Values (get $mapping "section") -}}
  {{- if and $vals (index $vals "enabled") -}}
    {{- $anyPerRole = true -}}
  {{- else -}}
    {{- $sharedRoles = append $sharedRoles $role -}}
  {{- end -}}
{{- end -}}
{{- if or .Values.memcached.enabled $anyPerRole -}}
caches:
{{- if not .Values.memcached.enabled -}}
{{- $sharedHost := printf "%s-memcached" $fullname -}}
{{- range $entry := (get (.Values.cache | default dict) "caches" | default list) -}}
  {{- if ne (tpl (toString (dig "memcached" "host" "" $entry)) $) $sharedHost -}}
    {{- $keep := list -}}
    {{- range $r := (get $entry "roles" | default list) -}}
      {{- if or (has $r $sharedRoles) (not (has $r $roles)) -}}
        {{- $keep = append $keep $r -}}
      {{- end -}}
    {{- end -}}
    {{- if $keep }}
  - {{ set (deepCopy $entry) "roles" $keep | toYaml | indent 4 | trim }}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end }}
{{- if and .Values.memcached.enabled (gt (len $sharedRoles) 0) }}
  - memcached:
      host: {{ $fullname }}-memcached
      service: memcached-client
      consistent_hash: {{ .Values.memcached.consistentHash }}
      timeout: {{ .Values.memcached.timeout }}
    roles:
    {{- range $sharedRoles }}
      - {{ . }}
    {{- end }}
{{- end }}
{{- range $role := $roles -}}
  {{- $mapping := get $perRoleMap $role -}}
  {{- $sectionName := get $mapping "section" -}}
  {{- $component   := get $mapping "component" -}}
  {{- $vals := index $.Values $sectionName -}}
  {{- if and $vals (index $vals "enabled") }}
  - memcached:
      host: {{ $fullname }}-{{ $component }}
      service: memcached-client
      consistent_hash: {{ index $vals "consistentHash" }}
      timeout: {{ index $vals "timeout" }}
    roles:
      - {{ $role }}
  {{- end -}}
{{- end }}
{{- else -}}
{{ toYaml .Values.cache }}
{{- end -}}
{{- end -}}

{{/*
Renders the overrides config
*/}}
{{- define "tempo.overridesConfig" -}}
overrides:
{{ toYaml .Values.per_tenant_overrides | indent 2 }}
{{- end -}}

{{/*
The volume to mount for tempo configuration
*/}}
{{- define "tempo.configVolume" -}}
{{- if eq .Values.configStorageType "Secret" -}}
secret:
  secretName: {{ tpl .Values.externalConfigSecretName . }}
{{- else if eq .Values.configStorageType "ConfigMap" -}}
configMap:
  name: {{ tpl .Values.externalConfigSecretName . }}
  items:
    - key: "tempo.yaml"
      path: "tempo.yaml"
{{- if .Values.queryFrontend.query.enabled }}
    - key: "tempo-query.yaml"
      path: "tempo-query.yaml"
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The volume to mount for tempo runtime configuration
*/}}
{{- define "tempo.runtimeVolume" -}}
configMap:
  name: {{ tpl .Values.externalRuntimeConfigName . }}
  items:
    - key: "overrides.yaml"
      path: "overrides.yaml"
{{- end -}}

{{/*
Internal servers http listen port - derived from Loki default
*/}}
{{- define "tempo.serverHttpListenPort" -}}
{{ (((.Values.tempo).structuredConfig).server).http_listen_port | default "3200" }}
{{- end -}}

{{/*
Internal servers grpc listen port - derived from Tempo default
*/}}
{{- define "tempo.serverGrpcListenPort" -}}
{{ (((.Values.tempo).structuredConfig).server).grpc_listen_port | default "9095" }}
{{- end -}}

{{/*
Memberlist bind port
*/}}
{{- define "tempo.memberlistBindPort" -}}
{{ (((.Values.tempo).structuredConfig).memberlist).bind_port | default "7946" }}
{{- end -}}

{{/*
Calculate values.yaml section name from component name
Expects the component name in .component on the passed context
*/}}
{{- define "tempo.componentSectionFromName" -}}
{{- .component | replace "-" "_" | camelcase | untitle -}}
{{- end -}}

{{/*
POD labels
*/}}
{{- define "tempo.podLabels" -}}
helm.sh/chart: {{ include "tempo.chart" .ctx }}
app.kubernetes.io/name: {{ include "tempo.name" .ctx }}
app.kubernetes.io/instance: {{ .ctx.Release.Name }}
app.kubernetes.io/version: {{ .ctx.Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .ctx.Release.Service }}
{{- if .component }}
app.kubernetes.io/component: {{ .component }}
{{- end }}
{{- if .memberlist }}
app.kubernetes.io/part-of: memberlist
{{- end -}}
{{- if .ctx.Values.global.commonLabels }}
{{ toYaml .ctx.Values.global.commonLabels | indent 0 }}
{{- end }}
{{- if .ctx.Values.global.podLabels }}
{{ toYaml .ctx.Values.global.podLabels | indent 0 }}
{{- end }}
{{- end -}}

{{/*
compute a ConfigMap or Secret checksum only based on its .data content.
This function needs to be called with a context object containing the following keys:
- ctx: the current Helm context (what '.' is at the call site)
- name: the file name of the ConfigMap or Secret
*/}}
{{- define "tempo.configMapOrSecretContentHash" -}}
{{ get (include (print .ctx.Template.BasePath .name) .ctx | fromYaml) "data" | toYaml | sha256sum }}
{{- end }}

{{/*
POD annotations
*/}}
{{- define "tempo.podAnnotations" -}}
{{- if .ctx.Values.useExternalConfig }}
checksum/config: {{ .ctx.Values.externalConfigVersion }}
{{- else -}}
checksum/config: {{ include "tempo.configMapOrSecretContentHash" (dict "ctx" .ctx "name" "/configmap-tempo.yaml") }}
{{- end }}
{{- with .ctx.Values.global.podAnnotations }}
{{ toYaml . }}
{{- end }}
{{- if .component }}
{{- $componentSection := include "tempo.componentSectionFromName" . }}
{{- if not (hasKey .ctx.Values $componentSection) }}
{{- print "Component section " $componentSection " does not exist" | fail }}
{{- end }}
{{- with (index .ctx.Values $componentSection).podAnnotations }}
{{ toYaml . }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Cluster name that shows up in dashboard metrics
*/}}
{{- define "tempo.clusterName" -}}
{{ (include "tempo.calculatedConfig" . | fromYaml).cluster_name | default .Release.Name }}
{{- end -}}

{{- define "tempo.memoryToMiB" -}}
{{- $mem := . | toString -}}
{{- if hasSuffix "Gi" $mem -}}
  {{- mulf ((trimSuffix "Gi" $mem) | float64) 1024 | int -}}
{{- else if hasSuffix "Mi" $mem -}}
  {{- (trimSuffix "Mi" $mem) | int -}}
{{- else if hasSuffix "G" $mem -}}
  {{- mulf ((trimSuffix "G" $mem) | float64) 953.6743164 | int -}}
{{- else if hasSuffix "M" $mem -}}
  {{- mulf ((trimSuffix "M" $mem) | float64) 0.9536743164 | int -}}
{{- else if hasSuffix "Ki" $mem -}}
  {{- divf ((trimSuffix "Ki" $mem) | float64) 1024 | int -}}
{{- else -}}
  {{- divf ($mem | float64) 1048576 | int -}}
{{- end -}}
{{- end -}}

{{/*
Build the env block for a Tempo component, auto-injecting GOMEMLIMIT and GOGC.

Arguments (passed as a dict):
  extraEnv  - already-concatenated extraEnv list for this component
  resources - the component's resources block (.Values.<component>.resources)
  factor    - fraction of memory limit for GOMEMLIMIT (default 0.85)
  gogc      - value for GOGC env var (default 80)

When the memory limit is not set, or GOMEMLIMIT is already defined in extraEnv,
the list is returned unchanged so users retain full control.
*/}}
{{- define "tempo.componentEnv" -}}
{{- $envList := .extraEnv | default list -}}
{{- $resources := .resources | default dict -}}
{{- $factor := .factor | default 0.85 | float64 -}}
{{- $gogc := .gogc | default 80 | int -}}
{{- $hasGomemlimit := false -}}
{{- $hasGogc := false -}}
{{- range $envList -}}
  {{- if eq .name "GOMEMLIMIT" -}}{{- $hasGomemlimit = true -}}{{- end -}}
  {{- if eq .name "GOGC" -}}{{- $hasGogc = true -}}{{- end -}}
{{- end -}}
{{- $memLimit := dig "limits" "memory" "" $resources -}}
{{- if and (not $hasGomemlimit) $memLimit -}}
  {{- $mib := include "tempo.memoryToMiB" $memLimit | int -}}
  {{- $goMemMib := mulf ($mib | float64) $factor | int -}}
  {{- $envList = append $envList (dict "name" "GOMEMLIMIT" "value" (printf "%dMiB" $goMemMib)) -}}
{{- end -}}
{{- if not $hasGogc -}}
  {{- $envList = append $envList (dict "name" "GOGC" "value" ($gogc | toString)) -}}
{{- end -}}
{{- with $envList | uniq -}}
env:
  {{- toYaml . | nindent 2 }}
{{- end -}}
{{- end -}}

{{- define "tempo.statefulset.recreateOnSizeChangeHook" -}}
  {{- $renderedStatefulSets := list -}}
  {{- range $renderedStatefulSet := include (print .context.Template.BasePath .pathToStatefulsetTemplate) .context | splitList "---" -}}
    {{- with $renderedStatefulSet | fromYaml -}}
      {{- $renderedStatefulSets = append $renderedStatefulSets . -}}
    {{- end }}
  {{- end -}}
  {{- if $renderedStatefulSets }}
    {{- range $newStatefulSet := $renderedStatefulSets -}}
      {{- $currentStatefulset := dict -}}
      {{- if $newStatefulSet.spec.volumeClaimTemplates }}
        {{- $currentStatefulset = lookup $newStatefulSet.apiVersion $newStatefulSet.kind $newStatefulSet.metadata.namespace $newStatefulSet.metadata.name -}}
        {{- $needsRecreation := false -}}
        {{- $templates := dict -}}
        {{- if $currentStatefulset -}}
          {{- if ne (len $newStatefulSet.spec.volumeClaimTemplates) (len $currentStatefulset.spec.volumeClaimTemplates) -}}
            {{- $needsRecreation = true -}}
          {{- end -}}
          {{- range $index, $newVolumeClaimTemplate := $newStatefulSet.spec.volumeClaimTemplates -}}
            {{- $currentVolumeClaimTemplateSpec := dict -}}
              {{- range $oldVolumeClaimTemplate := $currentStatefulset.spec.volumeClaimTemplates -}}
                {{- if eq $oldVolumeClaimTemplate.metadata.name $newVolumeClaimTemplate.metadata.name -}}
                  {{- $currentVolumeClaimTemplateSpec = $oldVolumeClaimTemplate.spec -}}
                {{- end -}}
              {{- end }}
              {{- $newVolumeClaimTemplateStorageSize := $newVolumeClaimTemplate.spec.resources.requests.storage -}}
              {{- if not $currentVolumeClaimTemplateSpec -}}
                {{- $needsRecreation = true -}}
              {{- else -}}
                {{- if ne $newVolumeClaimTemplateStorageSize $currentVolumeClaimTemplateSpec.resources.requests.storage -}}
                  {{- $needsRecreation = true -}}
                  {{- $templates = set $templates $newVolumeClaimTemplate.metadata.name $newVolumeClaimTemplateStorageSize -}}
              {{- end -}}
            {{- end -}}
          {{- end -}}
        {{- end -}}
        {{- if $needsRecreation }}
apiVersion: batch/v1
kind: Job
metadata:
  name: {{ $newStatefulSet.metadata.name }}-recreate
  namespace: {{ $newStatefulSet.metadata.namespace }}
  labels:
    {{- $newStatefulSet.metadata.labels | toYaml | nindent 4 }}
    app.kubernetes.io/component: statefulset-recreate-job
  annotations:
    "helm.sh/hook": pre-upgrade
    "helm.sh/hook-weight": "-5"
    "helm.sh/hook-delete-policy": before-hook-creation,hook-succeeded
spec:
  ttlSecondsAfterFinished: 300
  template:
    metadata:
      name: {{ $newStatefulSet.metadata.name }}-recreate
      labels:
        {{- $newStatefulSet.metadata.labels | toYaml | nindent 8 }}
    spec:
      serviceAccountName: {{ $newStatefulSet.metadata.name }}-recreate
      restartPolicy: OnFailure
      containers:
        - name: recreate
          image: {{ printf "%s/kubectl:%s" (coalesce $.context.Values.global.image.registry "registry.k8s.io") $.context.Capabilities.KubeVersion.Version }}
          command:
            - kubectl
            - delete
            - statefulset
            - {{ $newStatefulSet.metadata.name }}
            - --cascade=orphan
        {{- range $index := until (int $currentStatefulset.spec.replicas) }}
          {{- range $template, $size := $templates }}
        - name: patch-pvc-{{ $template }}-{{ $index }}
          image: {{ printf "%s/kubectl:%s" (coalesce $.context.Values.global.image.registry "registry.k8s.io") $.context.Capabilities.KubeVersion.Version }}
          command:
            - kubectl
            - patch
            - pvc
            - --namespace={{ $newStatefulSet.metadata.namespace }}
            - {{ printf "%s-%s-%d" $template $newStatefulSet.metadata.name $index }}
            - --type=json
            - '-p=[{"op": "replace", "path": "/spec/resources/requests/storage", "value": "{{ $size }}"}]'
          {{- end }}
        {{- end }}
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ $newStatefulSet.metadata.name }}-recreate
  namespace: {{ $newStatefulSet.metadata.namespace }}
  labels:
    {{- $newStatefulSet.metadata.labels | toYaml | nindent 4 }}
    app.kubernetes.io/component: statefulset-recreate-job
  annotations:
    "helm.sh/hook": pre-upgrade
    "helm.sh/hook-weight": "-10"
    "helm.sh/hook-delete-policy": before-hook-creation,hook-succeeded
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ $newStatefulSet.metadata.name }}-recreate
  namespace: {{ $newStatefulSet.metadata.namespace }}
  labels:
    {{- $newStatefulSet.metadata.labels | toYaml | nindent 4 }}
    app.kubernetes.io/component: statefulset-recreate-job
  annotations:
    "helm.sh/hook": pre-upgrade
    "helm.sh/hook-weight": "-10"
    "helm.sh/hook-delete-policy": before-hook-creation,hook-succeeded
rules:
  - apiGroups:
      - apps
    resources:
      - statefulsets
    resourceNames:
      - {{ $newStatefulSet.metadata.name }}
    verbs:
      - delete
  {{- if $templates }}
  - apiGroups:
      - ""
    resources:
      - persistentvolumeclaims
    resourceNames:
    {{- range $index := until (int $currentStatefulset.spec.replicas) }}
      {{- range $template := $templates | keys }}
      - {{ printf "%s-%s-%d" $template $newStatefulSet.metadata.name $index }}
      {{- end }}
    {{- end }}
    verbs:
      - patch
      - get
  {{- end }}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ $newStatefulSet.metadata.name }}-recreate
  namespace: {{ $newStatefulSet.metadata.namespace }}
  labels:
    {{- $newStatefulSet.metadata.labels | toYaml | nindent 4 }}
    app.kubernetes.io/component: statefulset-recreate-job
  annotations:
    "helm.sh/hook": pre-upgrade
    "helm.sh/hook-weight": "-10"
    "helm.sh/hook-delete-policy": before-hook-creation,hook-succeeded
subjects:
  - kind: ServiceAccount
    name: {{ $newStatefulSet.metadata.name }}-recreate
    namespace: {{ $newStatefulSet.metadata.namespace }}
roleRef:
  kind: Role
  name: {{ $newStatefulSet.metadata.name }}-recreate
  apiGroup: rbac.authorization.k8s.io
---
        {{- end }}
      {{ end }}
    {{ end }}
  {{ end }}
{{- end -}}

{{/*
volumeClaimTemplates (plus persistentVolumeClaimRetentionPolicy) for a stateful component.

Renders nothing when persistence is disabled, and nothing when persistence.inMemory is
true. In both of those cases tempo.podTemplate already provides the data volume inline --
an emptyDir, or an emptyDir with medium: Memory for inMemory. Emitting a claim of the same
name here as well would let the StatefulSet controller replace that inline volume with a
PVC, so the RAM disk asked for by inMemory would silently become a disk.

Args (dict):
  ctx        - root context
  component  - component values; reads .persistence and .persistentVolumeClaimRetentionPolicy
  name       - name of the data volume; must match the pod template's dataVolumeName

Callers render it at StatefulSet spec level, e.g.
  {{- with include "tempo.statefulset.volumeClaimTemplates" (dict "ctx" $ "component" .Values.x "name" "data") | trim }}
  {{- . | nindent 2 }}
  {{- end }}
*/}}
{{- define "tempo.statefulset.volumeClaimTemplates" -}}
{{- $persistence := .component.persistence -}}
{{- if and $persistence.enabled (not $persistence.inMemory) -}}
{{- $storageClass := $persistence.storageClass | default .ctx.Values.global.storageClass -}}
{{- if eq $storageClass "-" }}{{- $storageClass = "" }}{{- end -}}
{{- $retention := .component.persistentVolumeClaimRetentionPolicy | default dict -}}
{{- if $retention.enabled }}
persistentVolumeClaimRetentionPolicy:
  whenDeleted: {{ $retention.whenDeleted }}
  whenScaled: {{ $retention.whenScaled }}
{{- end }}
volumeClaimTemplates:
  - apiVersion: v1
    kind: PersistentVolumeClaim
    metadata:
      {{- with $persistence.annotations }}
      annotations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $persistence.labels }}
      labels:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      name: {{ .name }}
    spec:
      accessModes:
        - ReadWriteOnce
      storageClassName: {{ if $storageClass }}{{ $storageClass }}{{ else }}{{- "" }}{{ end }}
      resources:
        requests:
          storage: {{ $persistence.size | quote }}
{{- end -}}
{{- end -}}
